import React from 'react';
import { motion } from 'framer-motion';

interface AttractionSlideProps {
  attraction: 'aquarium' | 'american' | 'tokashiki' | 'cave' | 'dotonbori' | 'kokusai' | 'bund';
}

const AttractionSlide: React.FC<AttractionSlideProps> = ({ attraction }) => {
  // Attraction data based on the selected attraction
  const attractions = {
    aquarium: {
      title: '冲绳美之海水族馆',
      description: '世界上最大的水族馆之一，特色是巨大的黑潮水槽，内有鲸鲨和蝠鲼。水族馆展示了冲绳丰富的海洋生物，包括珊瑚礁和深海生物。',
      highlights: [
        '黑潮之海水槽：巨大的820万升水槽，饲养鲸鲨',
        '珊瑚礁水槽：美丽的活珊瑚礁生态系统',
        '海豚表演：每日多场演出',
        '深海展览：稀有深海生物展示',
        '海景咖啡厅：可观赏水槽的用餐体验'
      ],
      info: {
        位置: '本部町，冲绳北部',
        开放时间: '上午8:30 - 下午6:30（最后入场下午5:30）',
        门票: '成人: ¥2,200, 儿童: ¥730',
        交通时间: '90 分钟从 Naha 开车',
        建议游览时间: '3-4 开放时间'
      },
      imagePath: '/imgs/okinawa_aquarium.jpg',
      tips: [
        '提前到达以避免主水槽人群拥挤',
        '查看海豚和海牛的喂食时间表',
        '黑潮水槽的二楼提供最佳观赏视角',
        '如果可能的话，在工作日参观人会更少',
        '与附近景点的联票可以节省费用'
      ]
    },
    american: {
      title: '美国村',
      description: '一个充满活力的娱乐区，提供美式主题购物、餐饮和娱乐设施。特色包括摩天轮、餐厅、时尚精品店和娱乐场所，融合了独特的美式-冲绳风情。',
      highlights: [
        '美浜摩天轮：东海全景观赏',
        '海滨木板路：完美的日落漫步去处',
        '车站岛：购物和餐饮综合区',
        '现场音乐场所：定期演出',
        '日落海滩：紧邻村庄的小型海滩区'
      ],
      info: {
        位置: '北谷町，冲绳中部',
        开放时间: '因店铺而异（通常为上午10:00 - 下午10:00）',
        门票: '免费（各景点单独收费）',
        交通时间: '30 分钟从 Naha 开车',
        建议游览时间: '3-5小时'
      },
      imagePath: '/imgs/american_village.jpg',
      tips: [
        '傍晚参观可体验最佳灯光氛围',
        '日落时分的摩天轮乘坐特别美丽',
        '许多商店为游客提供免税购物',
        '购买纪念品的绝佳地点',
        '提供多个适合拍照的网红打卡点'
      ]
    },
    tokashiki: {
      title: '渡嘉敷岛阿波连海滩',
      description: '渡嘉敷岛上一处原始的白沙滩，拥有清澈的绿松石色海水。是慶良間诸岛的一部分，以日本最美丽的海滩和绝佳的浮潜潜水机会而闻名。',
      highlights: [
        '原始白沙滩：持续被评为日本最佳海滩之一',
        '浮潜天堂：丰富的珊瑚礁和热带鱼',
        '海龟观赏：夏季经常可见',
        '玻璃底船游：不用下水也能观赏海洋生物',
        '岛上风景步道：拥有全景视野的徒步小径'
      ],
      info: {
        位置: '渡嘉敷岛, 慶良間诸岛',
        开放时间: '海滩全天开放（服务时间上午9:00 - 下午5:00）',
        门票: '免费 (渡轮费用：¥3,310往返)',
        交通时间: '从那霸乘高速渡轮35分钟',
        建议游览时间: '全天行程'
      },
      imagePath: '/imgs/tokashiki_beach.jpg',
      tips: [
        '旺季期间提前1-2周预订渡轮票',
        '携带自己的浮潜装备或在岛上租赁',
        '食物选择有限 - 考虑携带零食',
        '岛上的班车与渡轮到达时间协调',
        '仔细查看返程渡轮时间 - 不要错过最后一班船！'
      ]
    },
    cave: {
      title: '玉泉洞',
      description: '一个壮观的30万年历史的石灰岩洞穴，拥有令人惊叹的钟乳石和石笋结构。总长5公里，是日本最大的洞穴系统之一，通过照明路径向游客开放约890米。',
      highlights: [
        '巨大的石灰岩构造：复杂的钟乳石和石笋',
        '地下河流：流经洞穴的清澈水流',
        '戏剧性灯光：突出最令人印象深刻的岩石构造',
        '便捷通道：全程维护良好的步道',
        '文化村落：洞穴附近的传统冲绳村落'
      ],
      info: {
        位置: '南城市，冲绳南部',
        开放时间: '上午9:00 - 下午6:00 (最晚入场下午5:30)',
        门票: '成人: ¥1,680, 儿童: ¥840',
        交通时间: '30 分钟从 Naha 开车',
        建议游览时间: '1-2 小时'
      },
      imagePath: '/imgs/gyokusendo_cave.webp',
      tips: [
        '洞穴保持恒温21°C，湿度较高',
        '穿舒适防滑鞋（地面可能湿滑）',
        '允许拍照但不允许使用三脚架',
        '与冲绳世界文化公园联票可省钱',
        '早上参观可避开团队游客人群'
      ]
    },
    dotonbori: {
      title: '大阪道顿堀',
      description: '大阪充满活力的娱乐和美食区，以其炫目的霓虹灯、动态广告牌和无数餐厅而闻名。运河边的步行道上排列着供应大阪著名街头美食和美味佳肴的餐厅。',
      highlights: [
        '格力高跑步人标志：标志性广告牌和拍照地点',
        '美食天堂：大阪街头美食文化中心',
        '惠比须桥：俯瞰运河的中心集合点',
        '法善寺横丁：气氛浓厚的狭窄小巷，有传统商店',
        '傍晚彩灯：天黑后壮观的霓虹灯展示'
      ],
      info: {
        位置: '中央区，大阪中心',
        开放时间: '因店铺而异（通常上午11:00至深夜）',
        门票: '免费',
        交通时间: '从难波站步行5分钟',
        建议游览时间: '3-4小时（晚上最佳）'
      },
      imagePath: '/imgs/dotonbori.jpg',
      tips: [
        '必尝美食：章鱼烧、大阪烧和串炸',
        '道顿堀在天黑后霓虹灯效果最佳',
        '乘坐运河游船获得不同视角',
        '工作日参观可避开极度拥挤的人群',
        '寻找3D广告牌，如巨大的移动螃蟹'
      ]
    },
    kokusai: {
      title: '国际通',
      description: '冲绳主要商业街，贯穿那霸市中心1.6公里，提供购物、餐饮和娱乐活动。被称为"奇迹之里"，拥有纪念品商店、当地工艺品、餐厅和文化体验。',
      highlights: [
        '传统工艺品：销售冲绳陶器、玻璃器皿和纺织品的商店',
        '美食多样性：从当地冲绳料理到国际选择',
        '牧志公共市场：附近的传统食品市场',
        '街头表演：偶尔有传统冲绳表演',
        '购物拱廊：从主干道分支出的有顶购物街'
      ],
      info: {
        位置: '那霸市，冲绳南部',
        开放时间: '大多数商店上午10:00 - 晚上8:00',
        门票: '免费',
        交通时间: '可乘坐单轨电车或从那霸市中心步行',
        建议游览时间: '3-4小时'
      },
      imagePath: '/imgs/kokusai_street.jpg',
      tips: [
        '参观专卖店购买正宗冲绳纪念品',
        '尝试冲绳特色美食，如塔可饭和蓝印冰淇淋',
        '探索小巷找到更多当地的、游客较少的商店',
        '有顶市场是雨天的好去处',
        '傍晚带来更热闹的氛围，餐厅和酒吧开始营业'
      ]
    },
    bund: {
      title: '上海外滩',
      description: '上海市中心著名的滨水区，通过令人印象深刻的欧式建筑展示城市的殖民历史，与黄浦江对岸未来主义的浦东天际线形成鲜明对比。',
      highlights: [
        '历史建筑：52栋多样建筑风格的建筑',
        '黄浦江景观：迷人的浦东现代天际线景色',
        '外滩步行道：沿着水边的流行步行道',
        '夜晚灯光：历史建筑和浦东均灯火通明',
        '高端购物和用餐：高级零售和餐厅选择'
      ],
      info: {
        位置: '黄浦区，上海',
        开放时间: '全天开放（步行道）',
        门票: '免费',
        交通时间: '从南京路步行可达',
        建议游览时间: '2-3小时（日落/晚上最佳）'
      },
      imagePath: '/imgs/shanghai_bund.jpg',
      tips: [
        '日落时参观，可同时欣赏白天和夜景',
        '乘坐江河游船欣赏两岸全景',
        '清晨参观可避开游客人群',
        '外滩连接南京路，可延伸观光',
        '傍晚灯光亮起时是拍照的最佳时机'
      ]
    },
  };

  const selected = attractions[attraction];

  return (
    <div className="w-full h-full flex flex-col overflow-y-auto relative bg-white/90 backdrop-blur-md rounded-xl">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-15 z-0" 
        style={{ backgroundImage: `url(${selected.imagePath})` }}
      ></div>

      <div className="relative z-10 p-12">
        {/* Title */}
        <motion.div 
          className="mb-6"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-blue-800">{selected.title}</h2>
          <div className="w-20 h-1 bg-blue-500 mt-2"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left column */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <div className="rounded-xl overflow-hidden shadow-lg mb-6">
              <img 
                src={selected.imagePath} 
                alt={selected.title} 
                className="w-full h-64 object-cover"
              />
            </div>

            <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
              <h3 className="text-xl font-bold text-blue-700 mb-3">描述</h3>
              <p className="text-gray-700">{selected.description}</p>
            </div>
          </motion.div>

          {/* Right column */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="space-y-6"
          >
            {/* 亮点 */}
            <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
              <h3 className="text-xl font-bold text-blue-700 mb-3">亮点</h3>
              <ul className="space-y-2">
                {selected.highlights.map((highlight, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center mt-0.5">
                      <span className="text-white text-xs font-bold">{index + 1}</span>
                    </div>
                    <span className="ml-2 text-gray-700">{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Practical Info */}
            <div className="bg-blue-50 rounded-lg p-5 shadow-sm border border-blue-100">
              <h3 className="text-xl font-bold text-blue-700 mb-3">实用信息</h3>
              <div className="space-y-2">
                <div className="flex">
                  <span className="font-bold text-blue-600 w-36">位置：</span>
                  <span className="text-gray-700">{selected.info.位置}</span>
                </div>
                <div className="flex">
                  <span className="font-bold text-blue-600 w-36">开放时间：</span>
                  <span className="text-gray-700">{selected.info.开放时间}</span>
                </div>
                <div className="flex">
                  <span className="font-bold text-blue-600 w-36">门票:</span>
                  <span className="text-gray-700">{selected.info.门票}</span>
                </div>
                <div className="flex">
                  <span className="font-bold text-blue-600 w-36">交通时间：</span>
                  <span className="text-gray-700">{selected.info.交通时间}</span>
                </div>
                <div className="flex">
                  <span className="font-bold text-blue-600 w-36">推荐：</span>
                  <span className="text-gray-700">{selected.info.建议游览时间}</span>
                </div>
              </div>
            </div>

            {/* 提示 */}
            <div className="bg-yellow-50 rounded-lg p-5 shadow-sm border border-yellow-100">
              <h3 className="text-xl font-bold text-yellow-700 mb-3">游客贴士</h3>
              <ul className="space-y-1 list-disc pl-5">
                {selected.tips.map((tip, index) => (
                  <li key={index} className="text-gray-700 text-sm">{tip}</li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AttractionSlide;