import React from 'react';
import { motion } from 'framer-motion';

const CarRentalSlide: React.FC = () => {
  return (
    <div className="w-full h-full flex flex-col p-12 overflow-y-auto relative bg-white/90 backdrop-blur-md rounded-xl">
      {/* Title */}
      <motion.div 
        className="mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-3xl font-bold text-blue-800">冲绳租车指南</h2>
        <div className="w-20 h-1 bg-blue-500 mt-2"></div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left content */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold text-blue-700 mb-3">租车选项</h3>
            <div className="space-y-4">
              <div className="border-l-4 border-blue-300 pl-3">
                <h4 className="font-bold text-blue-600">标准私家车（4人）</h4>
                <p className="text-sm text-gray-700"><span className="font-medium">全天（8小时）：</span> ¥30,000-35,000</p>
                <p className="text-sm text-gray-700"><span className="font-medium">半天（4小时）：</span> ¥18,000-22,000</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 轿车或小型SUV，含司机/导游</p>
              </div>
              
              <div className="border-l-4 border-indigo-300 pl-3">
                <h4 className="font-bold text-indigo-600">大型团队面包车（6-9人）</h4>
                <p className="text-sm text-gray-700"><span className="font-medium">全天（8小时）：</span> ¥40,000-45,000</p>
                <p className="text-sm text-gray-700"><span className="font-medium">半天（4小时）：</span> ¥25,000-30,000</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 宽敞面包车，含司机/导游</p>
              </div>

              <div className="border-l-4 border-purple-300 pl-3">
                <h4 className="font-bold text-purple-600">高级服务</h4>
                <p className="text-sm text-gray-700"><span className="font-medium">全天（8小时）：</span> ¥50,000+</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 豪华车辆，中文导游，个性化行程规划</p>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-5 shadow-sm border border-blue-100">
            <h3 className="text-xl font-bold text-blue-700 mb-3">推荐服务提供商</h3>
            <ul className="space-y-3">
              <li>
                <p className="font-bold text-blue-600">OTS Rent-A-Car</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 本地专业知识，日语和中文服务</p>
                <p className="text-sm text-gray-700"><span className="font-medium">网站：</span> www.otsinternational.jp/otsrentacar/en/</p>
              </li>
              <li>
                <p className="font-bold text-blue-600">Klook Private Charter</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 简便在线预订，良好的中文支持</p>
                <p className="text-sm text-gray-700"><span className="font-medium">网站：</span> www.klook.com</p>
              </li>
              <li>
                <p className="font-bold text-blue-600">Okinawa Tour Guide</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 优秀导游带您了解文化见解</p>
                <p className="text-sm text-gray-700"><span className="font-medium">网站：</span> okinawa-guide.jp</p>
              </li>
              <li>
                <p className="font-bold text-blue-600">Voyagin</p>
                <p className="text-sm text-gray-700"><span className="font-medium">特色：</span> 多种旅游选项，轻松取消</p>
                <p className="text-sm text-gray-700"><span className="font-medium">网站：</span> www.govoyagin.com</p>
              </li>
            </ul>
          </div>
        </motion.div>

        {/* Right content */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold text-blue-700 mb-3">包车服务优势</h3>
            <ul className="space-y-2 list-disc pl-5 text-gray-700">
              <li><span className="font-bold">便利性：</span> 直达所有景点的交通</li>
              <li><span className="font-bold">节省时间：</span> 无需研究公共交通</li>
              <li><span className="font-bold">本地知识：</span> 司机熟悉最佳路线和隐藏景点</li>
              <li><span className="font-bold">舒适性：</span> 空调车辆，有足够空间放置行李</li>
              <li><span className="font-bold">灵活性：</span> 可在当天定制您的行程</li>
              <li><span className="font-bold">语言支持：</span> 许多服务提供中文司机</li>
              <li><span className="font-bold">性价比：</span> 对4人以上的团队来说费用效益高</li>
            </ul>
          </div>

          <div className="bg-yellow-50 rounded-lg p-5 shadow-sm border border-yellow-100">
            <h3 className="text-xl font-bold text-yellow-700 mb-3">预订提示</h3>
            <ul className="space-y-2 list-disc pl-5 text-gray-700">
              <li><span className="font-bold">预订时间：</span> 提前3-4周预订</li>
              <li><span className="font-bold">行程规划：</span> 准备必访景点清单</li>
              <li><span className="font-bold">时间管理：</span> 合理安排可以参观的景点数量</li>
              <li><span className="font-bold">用餐计划：</span> 向司机询问当地餐厅推荐</li>
              <li><span className="font-bold">超时费用：</span> 通常每小时¥3,000-5,000</li>
              <li><span className="font-bold">确认：</span> 提前1天重新确认接送时间和地点</li>
            </ul>
          </div>

          <div className="bg-green-50 rounded-lg p-5 shadow-sm border border-green-100">
            <h3 className="text-xl font-bold text-green-700 mb-3">我们的包车计划</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-green-600">第1天 (8月5日): 冲绳北部游</h4>
                <ul className="ml-4 mt-1 space-y-1 text-sm list-disc pl-4">
                  <li>酒店接客: 上午9:00</li>
                  <li>美之海水族馆 (2.5小时)</li>
                  <li>在附近餐厅午餐 (1小时)</li>
                  <li>美国村 (3小时)</li>
                  <li>返回酒店: 晚上8:00</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-bold text-green-600">第2天 (8月6日): 冲绳南部游</h4>
                <ul className="ml-4 mt-1 space-y-1 text-sm list-disc pl-4">
                  <li>酒店接客: 上午9:00</li>
                  <li>玉泉洞 (2小时)</li>
                  <li>泊鱼市场午餐 (2小时)</li>
                  <li>ASHIBINAA奥特莱斯 (3小时)</li>
                  <li>返回酒店: 晚上8:00</li>
                </ul>
              </div>
              
              <div>
                <p className="text-sm italic text-gray-600">
                  * 两天总费用: 约¥70,000 (¥35,000/天)
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CarRentalSlide;